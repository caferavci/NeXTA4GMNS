/* projection list for program nad2nad */
PROJ_HEAD(lcc, "Lambert Conformal Conic")
PROJ_HEAD(omerc, "Oblique Mercator")
PROJ_HEAD(poly, "Polyconic (American)")
PROJ_HEAD(tmerc, "Transverse Mercator")
PROJ_HEAD(utm, "Universal Transverse Mercator (UTM)")
